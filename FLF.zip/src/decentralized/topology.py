"""Network topology creation for P2P federated learning."""

import networkx as nx
import numpy as np
from typing import Tuple, Dict, Literal

try:
    import cvxpy as cp
    CVXPY_AVAILABLE = True
except ImportError:
    CVXPY_AVAILABLE = False

# Type alias for mixing methods
MixingMethod = Literal['metropolis_hastings', 'max_degree', 'jaccard', 'jaccard_dissimilarity', 'matcha']

# Module-level cache for MATCHA weights (avoid re-solving CVX every round)
_matcha_cache: Dict[int, np.ndarray] = {}


def create_two_cluster_topology(
    num_clients: int,
    main_link_prob: float = 1.0,
    border_link_prob: float = 1.0,
    intra_cluster_prob: float = 0.8,
    intra_cluster_communication: bool = True
) -> nx.Graph:
    """Create a symmetrical two-cluster network topology.
    
    This creates two identically structured clusters with a bridge connection between them.
    The clusters are perfectly symmetrical - they have the same internal structure.
    
    Args:
        num_clients: Total number of clients (should be even for perfect symmetry)
        main_link_prob: Probability of main bridge link activation
        border_link_prob: Probability of border links activation
        intra_cluster_prob: Probability of edges within clusters
        
    Returns:
        NetworkX graph representing the topology
    """
    if num_clients < 4:
        raise ValueError("Need at least 4 clients for two-cluster topology")
    
    G = nx.Graph()
    G.add_nodes_from(range(num_clients))
    
    # Split into two clusters evenly
    cluster_size = num_clients // 2
    cluster1 = list(range(cluster_size))
    cluster2 = list(range(cluster_size, num_clients))
    
    print(f"Creating symmetrical clusters: Cluster 0 ({len(cluster1)} clients), Cluster 1 ({len(cluster2)} clients)")
    
    if intra_cluster_communication:
        # All nodes in a cluster are interconnected (current behavior)
        cluster1_edges = []
        for i in range(len(cluster1)):
            for j in range(i + 1, len(cluster1)):
                if np.random.random() < intra_cluster_prob:
                    cluster1_edges.append((i, j))
        # Add cluster 1 edges (using actual node IDs)
        for i, j in cluster1_edges:
            G.add_edge(cluster1[i], cluster1[j], probability_selection=intra_cluster_prob)
        # Mirror edges to cluster 2 (maintaining symmetry)
        for i, j in cluster1_edges:
            G.add_edge(cluster2[i], cluster2[j], probability_selection=intra_cluster_prob)
    else:
        # Only edge node in each cluster connects to others in the cluster (star topology)
        # Choose the first node in each cluster as the edge node
        edge1 = cluster1[0]
        edge2 = cluster2[0]
        for node in cluster1:
            if node != edge1:
                G.add_edge(edge1, node, probability_selection=intra_cluster_prob)
        for node in cluster2:
            if node != edge2:
                G.add_edge(edge2, node, probability_selection=intra_cluster_prob)
    
    # Find center nodes (highest degree in each cluster)
    # Due to symmetry, centers will be at the same relative position
    cluster1_degrees = [(node, G.degree(node)) for node in cluster1]
    cluster2_degrees = [(node, G.degree(node)) for node in cluster2]
    
    center1 = max(cluster1_degrees, key=lambda x: x[1])[0]
    center2 = max(cluster2_degrees, key=lambda x: x[1])[0]
    
    print(f"  Cluster 0 center: Client {center1} (degree {G.degree(center1)})")
    print(f"  Cluster 1 center: Client {center2} (degree {G.degree(center2)})")
    
    # Add ONLY ONE bridge link between the two clusters (connecting centers)
    G.add_edge(center1, center2, probability_selection=main_link_prob)
    print(f"  Bridge link: {center1}-{center2} (single connection between clusters)")
    
    # Verify symmetry
    cluster1_edge_count = len([(u, v) for u, v in G.edges() if u in cluster1 and v in cluster1])
    cluster2_edge_count = len([(u, v) for u, v in G.edges() if u in cluster2 and v in cluster2])
    inter_cluster_edges = len([(u, v) for u, v in G.edges() if (u in cluster1 and v in cluster2) or (u in cluster2 and v in cluster1)])
    print(f"  Internal edges: Cluster 0 = {cluster1_edge_count}, Cluster 1 = {cluster2_edge_count}")
    print(f"  Inter-cluster edges: {inter_cluster_edges}")
    
    return G


def create_mixing_matrix(
    graph: nx.Graph,
    num_clients: int,
    method: MixingMethod = 'metropolis_hastings'
) -> np.ndarray:
    """Create mixing matrix for gossip aggregation.
    
    The mixing matrix defines how much weight each client gives to itself
    and its neighbors during aggregation.
    
    Args:
        graph: Network topology graph
        num_clients: Number of clients
        method: Mixing method to use ('metropolis_hastings', 'max_degree', 'jaccard', 'matcha')
        
    Returns:
        Mixing matrix (W) of shape (num_clients, num_clients)
    """
    if method == 'metropolis_hastings':
        return _metropolis_hastings_weights(graph, num_clients)
    elif method == 'max_degree':
        return _max_degree_weights(graph, num_clients)
    elif method == 'jaccard':
        return _jaccard_weights(graph, num_clients)
    elif method == 'jaccard_dissimilarity':
        return _jaccard_dissimilarity_weights(graph, num_clients)
    elif method == 'matcha':
        return _matcha_weights(graph, num_clients)
    else:
        raise ValueError(f"Unknown mixing method: {method}")


def _metropolis_hastings_weights(graph: nx.Graph, num_clients: int) -> np.ndarray:
    """Metropolis-Hastings mixing weights.
    
    Weight between i and j: 1 / (1 + max(degree_i, degree_j))
    """
    W = np.zeros((num_clients, num_clients))
    
    for node in range(num_clients):
        neighbors = list(graph.neighbors(node))
        degree = len(neighbors)
        
        for neighbor in neighbors:
            neighbor_degree = len(list(graph.neighbors(neighbor)))
            max_degree = max(degree, neighbor_degree)
            W[node, neighbor] = 1.0 / (max_degree + 1)
        
        # Self-weight: ensure rows sum to 1
        W[node, node] = 1.0 - W[node, :].sum()
    
    return W


def _max_degree_weights(graph: nx.Graph, num_clients: int) -> np.ndarray:
    """Maximum degree mixing weights.
    
    All edges use weight 1/max_degree where max_degree is the maximum
    degree in the entire graph.
    """
    W = np.zeros((num_clients, num_clients))
    
    # Find maximum degree in graph
    if len(graph.edges()) == 0:
        return np.eye(num_clients)
    
    max_degree = max(dict(graph.degree()).values())
    
    for node in range(num_clients):
        neighbors = list(graph.neighbors(node))
        
        # Edge weights
        for neighbor in neighbors:
            W[node, neighbor] = 1.0 / max_degree
        
        # Self-weight
        degree = len(neighbors)
        W[node, node] = 1.0 - degree / max_degree
    
    return W


def _jaccard_weights(graph: nx.Graph, num_clients: int) -> np.ndarray:
    """
    Jaccard dissimilarity mixing weights (standalone variant).

    For each edge (i,j), using closed neighborhoods N[i] = {i} ∪ neighbors(i):
        J(i,j)  = |N[i] ∩ N[j]| / |N[i] ∪ N[j]|   (Jaccard similarity)
        y_ij    = 1 - J(i,j)                          (dissimilarity → weight)

    Normalization:
        - Per-node row normalization if row sum > 1
        - Symmetrize: w_ij = min(y_ij, y_ji)
        - Self-loop:  w_ii = 1 - sum of off-diagonal row weights
    """
    if len(graph.edges()) == 0:
        return np.eye(num_clients)

    # Step 1: compute raw directed weights
    Y = np.zeros((num_clients, num_clients))
    for i in range(num_clients):
        set_i = set(graph.neighbors(i)) | {i}
        for j in graph.neighbors(i):
            set_j = set(graph.neighbors(j)) | {j}
            intersection = len(set_i & set_j)
            union        = len(set_i | set_j)
            Y[i, j] = 1.0 - intersection / union  # in [0, 1]

    # Step 2: per-node row normalization (only rescales if sum > 1)
    for i in range(num_clients):
        row_sum = Y[i, :].sum()
        if row_sum > 1.0:
            Y[i, :] /= row_sum

    # Step 3: symmetrize via min, then self-loops
    W = np.zeros((num_clients, num_clients))
    for i in range(num_clients):
        for j in graph.neighbors(i):
            W[i, j] = min(Y[i, j], Y[j, i])
        W[i, i] = max(1.0 - W[i, :].sum(), 0.0)

    # Sanity check (remove in production)
    assert np.allclose(W, W.T, atol=1e-6), "W is not symmetric"
    assert np.all(W >= 0),                 "W has negative entries"
    assert np.allclose(W.sum(axis=1), 1.0, atol=1e-6), "Rows don't sum to 1"

    return W

def _jaccard_dissimilarity_weights(graph: nx.Graph, num_clients: int) -> np.ndarray:
    """
    Neighborhood Algorithm mixing weights (Avrachenkov et al., 2011).
    Uses closed neighborhoods N[i] = {i} ∪ neighbors(i).

    For each edge (i, j):
        y_ij = 1 - |N[i] ∩ N[j]| / (1 + 2*min(|N[i]|, |N[j]|) - |N[i] ∩ N[j]|)

    Then per Algorithm 1:
      - Per-node row normalization if row sum > 1
      - Symmetrize: w_ij = min(y_ij, y_ji)
      - Self-loop: w_ii = 1 - sum of off-diagonal weights
    """
    if len(graph.edges()) == 0:
        return np.eye(num_clients)

    # Step 2: compute raw y_ij for each directed edge
    Y = np.zeros((num_clients, num_clients))
    for i in range(num_clients):
        set_i = set(graph.neighbors(i)) | {i}
        for j in graph.neighbors(i):
            set_j = set(graph.neighbors(j)) | {j}
            intersection = len(set_i & set_j)
            denom = 1 + 2 * min(len(set_i), len(set_j)) - intersection
            Y[i, j] = 1.0 - intersection / denom

    # Step 3: per-node row normalization (only if row sum > 1)
    for i in range(num_clients):
        row_sum = np.sum(Y[i, :])
        if row_sum > 1.0:
            Y[i, :] /= row_sum

    # Step 5: symmetrize with min, then self-loops
    W = np.zeros((num_clients, num_clients))
    for i in range(num_clients):
        for j in graph.neighbors(i):
            W[i, j] = min(Y[i, j], Y[j, i])
        W[i, i] = max(1.0 - np.sum(W[i, :]), 0.0)

    return W

def _matcha_weights(graph: nx.Graph, num_clients: int) -> np.ndarray:
    """MATCHA (Optimal) mixing weights using convex optimization.
    
    Uses CVX optimization to find optimal edge activation probabilities
    and mixing weights for fastest convergence.
    
    Requires: cvxpy library
    """
    if not CVXPY_AVAILABLE:
        print("Warning: cvxpy not available. Falling back to Metropolis-Hastings.")
        return _metropolis_hastings_weights(graph, num_clients)
    
    if len(graph.edges()) == 0:
        return np.eye(num_clients)
    
    try:
        # Get subgraphs (connected components)
        subgraphs = list(nx.connected_components(graph))
        
        if len(subgraphs) > 1:
            # Graph is not connected, use simpler method
            print("Warning: Graph not connected. Using Metropolis-Hastings for MATCHA.")
            return _metropolis_hastings_weights(graph, num_clients)
        
        # Compute Laplacian matrix
        L = nx.laplacian_matrix(graph).toarray()
        
        # Get optimal activation probabilities using CVX
        edge_probs = _get_optimal_probabilities(graph, L)
        
        # Compute mixing weights using SDP
        W = _get_optimal_alpha(graph, edge_probs, num_clients)
        
        return W
        
    except Exception as e:
        print(f"MATCHA optimization failed: {e}. Falling back to Metropolis-Hastings.")
        return _metropolis_hastings_weights(graph, num_clients)


def _get_optimal_probabilities(graph: nx.Graph, L: np.ndarray) -> Dict[Tuple[int, int], float]:
    """Compute optimal edge activation probabilities for MATCHA.
    
    Solves CVX problem to maximize expected spectral gap.
    """
    edges = list(graph.edges())
    n_edges = len(edges)
    
    # Create CVX variables
    p = cp.Variable(n_edges, nonneg=True)
    
    # Objective: maximize spectral gap (minimize trace of expected Laplacian)
    # Expected Laplacian: sum_e p_e * L_e
    objective = cp.Minimize(cp.sum(p))
    
    # Constraints
    constraints = [
        p >= 0.1,  # Minimum probability
        p <= 1.0,  # Maximum probability
        cp.sum(p) >= 1.0  # At least one edge active in expectation
    ]
    
    # Solve
    problem = cp.Problem(objective, constraints)
    try:
        # Try CVXOPT first, fall back to SCS (bundled with cvxpy)
        try:
            problem.solve(solver=cp.CVXOPT, kktsolver=cp.ROBUST_KKTSOLVER)
        except (cp.error.SolverError, Exception):
            problem.solve(solver=cp.SCS)
        
        if problem.status not in ["optimal", "optimal_inaccurate"]:
            # If optimization fails, use uniform probabilities
            return {edge: 1.0 for edge in edges}
        
        # Extract probabilities
        edge_probs = {}
        for i, edge in enumerate(edges):
            prob = float(p.value[i]) if p.value is not None else 1.0
            edge_probs[edge] = min(max(prob, 0.1), 1.0)  # Clamp to [0.1, 1.0]
            edge_probs[(edge[1], edge[0])] = edge_probs[edge]  # Symmetric
        
        return edge_probs
        
    except Exception as e:
        print(f"CVX optimization failed: {e}")
        return {edge: 1.0 for edge in edges}


def _get_optimal_alpha(
    graph: nx.Graph,
    edge_probs: Dict[Tuple[int, int], float],
    num_clients: int
) -> np.ndarray:
    """Compute optimal mixing weights alpha for MATCHA using SDP.
    
    Given edge probabilities, find mixing weights that optimize convergence.
    """
    W = np.zeros((num_clients, num_clients))
    
    # For each node, distribute weight among active neighbors
    for node in range(num_clients):
        neighbors = list(graph.neighbors(node))
        
        if not neighbors:
            W[node, node] = 1.0
            continue
        
        # Get expected weights based on probabilities
        total_prob = 0.0
        for neighbor in neighbors:
            prob = edge_probs.get((node, neighbor), 1.0)
            W[node, neighbor] = prob / (1 + len(neighbors))
            total_prob += W[node, neighbor]
        
        # Self-weight
        W[node, node] = 1.0 - total_prob
    
    return W


def get_active_edges(
    graph: nx.Graph,
    round_num: int,
    seed: int = None
) -> Dict[Tuple[int, int], bool]:
    """Determine which edges are active in this round based on probabilities.
    
    Args:
        graph: Network topology graph
        round_num: Current round number
        seed: Random seed for reproducibility
        
    Returns:
        Dictionary mapping edges to activation status
    """
    if seed is not None:
        np.random.seed(seed + round_num)
    
    active_edges = {}
    
    for edge in graph.edges():
        prob = graph.edges[edge].get('probability_selection', 1.0)
        is_active = np.random.random() < prob
        active_edges[edge] = is_active
        active_edges[(edge[1], edge[0])] = is_active  # Undirected
    
    return active_edges


def get_active_mixing_matrix(
    graph: nx.Graph,
    num_clients: int,
    active_edges: Dict[Tuple[int, int], bool],
    method: MixingMethod = 'metropolis_hastings'
) -> np.ndarray:
    """Create mixing matrix considering only active edges.
    
    Args:
        graph: Network topology graph
        num_clients: Number of clients
        active_edges: Dictionary of edge activation status
        method: Mixing method to use
        
    Returns:
        Active mixing matrix
    """
    if method == 'metropolis_hastings':
        return _active_metropolis_hastings(graph, num_clients, active_edges)
    elif method == 'max_degree':
        return _active_max_degree(graph, num_clients, active_edges)
    elif method == 'jaccard':
        return _active_jaccard(graph, num_clients, active_edges)
    elif method == 'jaccard_dissimilarity':
        return _active_jaccard_dissimilarity(graph, num_clients, active_edges)
    elif method == 'matcha':
        return _active_matcha(graph, num_clients, active_edges)
    else:
        raise ValueError(f"Unknown mixing method: {method}")


def _active_metropolis_hastings(
    graph: nx.Graph,
    num_clients: int,
    active_edges: Dict[Tuple[int, int], bool]
) -> np.ndarray:
    """Metropolis-Hastings with active edges only."""
    W = np.zeros((num_clients, num_clients))
    
    for node in range(num_clients):
        neighbors = list(graph.neighbors(node))
        active_neighbors = [n for n in neighbors if active_edges.get((node, n), False)]
        
        if not active_neighbors:
            W[node, node] = 1.0
            continue
        
        degree = len(active_neighbors)
        
        for neighbor in active_neighbors:
            neighbor_active = [n for n in graph.neighbors(neighbor) 
                             if active_edges.get((neighbor, n), False)]
            neighbor_degree = len(neighbor_active)
            max_degree = max(degree, neighbor_degree)
            W[node, neighbor] = 1.0 / (max_degree + 1)
        
        W[node, node] = 1.0 - W[node, :].sum()
    
    return W


def _active_max_degree(
    graph: nx.Graph,
    num_clients: int,
    active_edges: Dict[Tuple[int, int], bool]
) -> np.ndarray:
    """Max degree with active edges only."""
    W = np.zeros((num_clients, num_clients))
    
    # Find max degree considering only active edges
    max_degree = 0
    for node in range(num_clients):
        neighbors = list(graph.neighbors(node))
        active_neighbors = [n for n in neighbors if active_edges.get((node, n), False)]
        max_degree = max(max_degree, len(active_neighbors))
    
    if max_degree == 0:
        return np.eye(num_clients)
    
    for node in range(num_clients):
        neighbors = list(graph.neighbors(node))
        active_neighbors = [n for n in neighbors if active_edges.get((node, n), False)]
        
        if not active_neighbors:
            W[node, node] = 1.0
            continue
        
        for neighbor in active_neighbors:
            W[node, neighbor] = 1.0 / max_degree
        
        degree = len(active_neighbors)
        W[node, node] = 1.0 - degree / max_degree
    
    return W


def _active_jaccard(
    graph: nx.Graph,
    num_clients: int,
    active_edges: Dict[Tuple[int, int], bool]
) -> np.ndarray:
    """Jaccard dissimilarity with active edges only.

    Mirrors the same Algorithm 1 steps as _jaccard_weights:
      1. Compute raw y_ij = 1 - |N[i] ∩ N[j]| / |N[i] ∪ N[j]| (closed neighborhoods)
      2. Per-node row normalisation if row sum > 1
      3. Symmetrize: w_ij = min(y_ij, y_ji)
      4. Self-loop: w_ii = 1 - sum of off-diagonal weights
    """
    # Build active closed neighborhood sets
    active_neighbors_map = {
        node: set(
            n for n in graph.neighbors(node)
            if active_edges.get((node, n), False)
        )
        for node in range(num_clients)
    }

    if all(len(ns) == 0 for ns in active_neighbors_map.values()):
        return np.eye(num_clients)

    # Step 1: raw directed weights
    Y = np.zeros((num_clients, num_clients))
    for i in range(num_clients):
        set_i = active_neighbors_map[i] | {i}
        for j in active_neighbors_map[i]:
            set_j = active_neighbors_map[j] | {j}
            intersection = len(set_i & set_j)
            union        = len(set_i | set_j)
            Y[i, j] = 1.0 - intersection / union

    # Step 2: per-node row normalisation (only if sum > 1)
    for i in range(num_clients):
        row_sum = Y[i, :].sum()
        if row_sum > 1.0:
            Y[i, :] /= row_sum

    # Step 3 & 4: symmetrize via min, then self-loops
    W = np.zeros((num_clients, num_clients))
    for i in range(num_clients):
        for j in active_neighbors_map[i]:
            W[i, j] = min(Y[i, j], Y[j, i])
        W[i, i] = max(1.0 - W[i, :].sum(), 0.0)

    return W


def _active_jaccard_dissimilarity(
    graph: nx.Graph,
    num_clients: int,
    active_edges: Dict[Tuple[int, int], bool]
) -> np.ndarray:
    """Neighborhood Algorithm (Avrachenkov et al., 2011) with active edges only.

    Uses closed neighborhoods restricted to currently active edges:
        N_active[i] = {i} ∪ {j : (i,j) active}
    Mirrors the same Algorithm 1 steps as _jaccard_dissimilarity_weights:
      1. Compute raw y_ij for each active directed edge
      2. Per-node row normalisation if row sum > 1
      3. Symmetrize: w_ij = min(y_ij, y_ji)
      4. Self-loop: w_ii = 1 - sum of off-diagonal weights
    """
    # Build active closed neighborhood sets
    active_neighbors_map = {
        node: set(
            n for n in graph.neighbors(node)
            if active_edges.get((node, n), False)
        )
        for node in range(num_clients)
    }

    if all(len(ns) == 0 for ns in active_neighbors_map.values()):
        return np.eye(num_clients)

    # Step 1: raw y_ij for each active directed edge
    Y = np.zeros((num_clients, num_clients))
    for i in range(num_clients):
        set_i = active_neighbors_map[i] | {i}
        for j in active_neighbors_map[i]:
            set_j = active_neighbors_map[j] | {j}
            intersection = len(set_i & set_j)
            denom = 1 + 2 * min(len(set_i), len(set_j)) - intersection
            Y[i, j] = 1.0 - intersection / denom

    # Step 2: per-node row normalisation (only if row sum > 1)
    for i in range(num_clients):
        row_sum = np.sum(Y[i, :])
        if row_sum > 1.0:
            Y[i, :] /= row_sum

    # Step 3 & 4: symmetrize with min, then self-loops
    W = np.zeros((num_clients, num_clients))
    for i in range(num_clients):
        for j in active_neighbors_map[i]:
            W[i, j] = min(Y[i, j], Y[j, i])
        W[i, i] = max(1.0 - np.sum(W[i, :]), 0.0)

    return W


def _active_matcha(
    graph: nx.Graph,
    num_clients: int,
    active_edges: Dict[Tuple[int, int], bool]
) -> np.ndarray:
    """MATCHA with active edges only.
    
    Computes the full MATCHA mixing matrix once (cached), then for each
    round keeps only active edge weights and redistributes inactive
    weight to self-loops so rows still sum to 1.
    """
    global _matcha_cache
    
    # Compute full MATCHA weights once and cache by graph identity
    cache_key = id(graph)
    if cache_key not in _matcha_cache:
        _matcha_cache[cache_key] = _matcha_weights(graph, num_clients)
    
    W_full = _matcha_cache[cache_key]
    
    # Build active mixing matrix: keep MATCHA weights for active edges only
    W = np.zeros((num_clients, num_clients))
    
    for node in range(num_clients):
        neighbors = list(graph.neighbors(node))
        active_neighbors = [n for n in neighbors
                            if active_edges.get((node, n), False)]
        
        for neighbor in active_neighbors:
            W[node, neighbor] = W_full[node, neighbor]
        
        # Self-weight absorbs weight from inactive edges
        W[node, node] = 1.0 - np.sum(W[node, :])
    
    return W
