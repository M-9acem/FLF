#!/bin/bash -l
#SBATCH --job-name=fl_hypparams_runner
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --partition=gpu
#SBATCH --gpus-per-node=4
#SBATCH --mem=120G
#SBATCH --time=72:00:00
#SBATCH --signal=B:TERM@600

set -euo pipefail

# Keep all debug artifacts for this run in one directory.
RUN_TS="$(date +%Y-%m-%d_%H-%M-%S)"
JOB_TAG="${SLURM_JOB_ID:-local}_${RUN_TS}"
DEBUG_DIR="logs/slurm_debug/${JOB_TAG}"
mkdir -p "${DEBUG_DIR}"

# Mirror stdout/stderr to a persistent log file.
exec > >(tee -a "${DEBUG_DIR}/slurm_run.log") 2>&1

# ─── setup ────────────────────────────────────────────────────
cd "$SLURM_SUBMIT_DIR" || { echo "Failed to cd to $SLURM_SUBMIT_DIR"; exit 1; }
mkdir -p logs

echo "Debug directory: ${DEBUG_DIR}"
echo "Job started on $(hostname) at $(date)"
echo "Working directory: $(pwd)"
echo "User: $(whoami)"

echo ""
echo "===== SLURM / CUDA ENV ====="
env | grep -E '^(SLURM|CUDA|NVIDIA|CONDA|VIRTUAL_ENV)_' | sort || true

# Initialize conda (works in non-interactive shells)
if [ -f "$HOME/.bashrc" ]; then
    source "$HOME/.bashrc"
fi
eval "$(conda shell.bash hook 2>/dev/null)" || true

if [ ! -d fl_hypparams_runner_env ]; then
    python3 -m venv fl_hypparams_runner_env
fi
source fl_hypparams_runner_env/bin/activate

# ─── diagnostics ──────────────────────────────────────────────
echo ""
echo "===== SYSTEM GPU DIAGNOSTICS ====="
if command -v nvidia-smi >/dev/null 2>&1; then
    nvidia-smi -L || true
    nvidia-smi || true
else
    echo "nvidia-smi not found in PATH"
fi

if command -v nvcc >/dev/null 2>&1; then
    nvcc --version || true
else
    echo "nvcc not found in PATH"
fi

echo ""
echo "===== PYTHON RUNTIME DIAGNOSTICS ====="
which python || true
python --version || true
pip --version || true

python -u -c "
import torch
import os
import platform
from datetime import datetime

print('timestamp     ', datetime.now().isoformat())
print('platform      ', platform.platform())
print('python exec   ', os.sys.executable)
print('torch        ', torch.__version__)
print('torch file   ', torch.__file__)
print('cuda avail   ', torch.cuda.is_available())
print('cuda version ', torch.version.cuda)
print('cuda devices ', torch.cuda.device_count())
if torch.cuda.is_available():
    print('gpu name     ', torch.cuda.get_device_name(0))
    print('current dev  ', torch.cuda.current_device())
else:
    print('cuda reason  ', 'CUDA not available from this process')
"

echo ""
echo "===== TORCH PACKAGE INFO ====="
pip show torch torchvision torchaudio || true

# ─── install requirements ─────────────────────────────────────
echo ""
echo "Installing/updating requirements..."
pip install -r requirements.txt || echo "Warning: requirements.txt not found or install failed"

# Save a post-install CUDA check so we can compare before/after pip install.
python -u -c "
import json
import torch
from datetime import datetime

payload = {
    'timestamp': datetime.now().isoformat(),
    'torch_version': torch.__version__,
    'cuda_available': torch.cuda.is_available(),
    'cuda_version': torch.version.cuda,
    'cuda_device_count': torch.cuda.device_count(),
}
with open('logs/slurm_debug/${JOB_TAG}/torch_cuda_check.json', 'w') as f:
    json.dump(payload, f, indent=2)
print(payload)
"

# Quick single-round probe to verify device selection path in main.py.
echo ""
echo "===== QUICK DEVICE PROBE (CENTRALIZED) ====="
python -u main.py \
  --type centralized \
  --num_clients 1 \
  --rounds 1 \
  --epochs 1 \
  --dataset mnist \
  --model lenet5 \
  --batch_size 64 \
  --num_workers 2 \
  --experiment_name slurm_gpu_probe \
  --log_dir "${DEBUG_DIR}/probe_logs" || true

# ─── run delay-runner experiment ──────────────────────────────
echo ""
echo "=========================================="
echo "Starting SLURM smoke experiment"
echo "=========================================="
echo "This will run:"
echo "  1. Tiny decentralized run (MNIST, 4 clients, 2 rounds)"
echo "  2. Config loaded from experiments_slurm_smoke.yaml"
echo "=========================================="
echo ""

python3 -u run_all_mixing_methods.py --experiments_yaml experiments_slurm_smoke.yaml

echo ""
echo "Job finished at $(date)"
echo "Debug artifacts saved under: ${DEBUG_DIR}"
